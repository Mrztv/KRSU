library verilog;
use verilog.vl_types.all;
entity lab3_1 is
    port(
        A               : out    vl_logic;
        C               : in     vl_logic;
        G               : in     vl_logic;
        W               : in     vl_logic
    );
end lab3_1;
