module f_variant1 (f, x1, x2, x3);
	input x1, x2, x3;
	output f;
	reg f;
	
	always @ (x1 or x2 or x3)
		begin
			case ({x1,x2,x3})
				3'b000: f = 0;
				3'b001: f = 1;
				3'b010: f = 0;
				3'b011: f = 0;
				3'b100: f = 0;
				3'b101: f = 1;
				3'b110: f = 1;
				3'b111: f = 1;
			endcase
		end
endmodule
